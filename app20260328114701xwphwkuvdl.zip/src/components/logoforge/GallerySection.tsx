'use client';

import { useRef, useEffect, useState } from 'react';
import { Sparkles } from 'lucide-react';
import { motion, useInView } from 'framer-motion';
import { cn } from '@/lib/utils';

type FilterCategory = 'all' | 'tech' | 'luxury' | 'minimalist' | 'retro' | 'abstract';

const filters: { label: string; value: FilterCategory }[] = [
  { label: 'All', value: 'all' },
  { label: 'Tech', value: 'tech' },
  { label: 'Luxury', value: 'luxury' },
  { label: 'Minimalist', value: 'minimalist' },
  { label: 'Retro', value: 'retro' },
  { label: 'Abstract', value: 'abstract' },
];

const galleryItems = [
  { id: 1, name: 'TechFlow', category: 'tech', gradient: 'from-violet-600 to-blue-600', icon: 'T' },
  { id: 2, name: 'Luxe', category: 'luxury', gradient: 'from-amber-500 to-yellow-400', icon: 'L' },
  { id: 3, name: 'Zen', category: 'minimalist', gradient: 'from-slate-400 to-slate-600', icon: 'Z' },
  { id: 4, name: 'RetroWave', category: 'retro', gradient: 'from-pink-500 to-orange-500', icon: 'R' },
  { id: 5, name: 'Neural', category: 'abstract', gradient: 'from-cyan-500 to-blue-600', icon: 'N' },
  { id: 6, name: 'CloudBase', category: 'tech', gradient: 'from-blue-500 to-indigo-600', icon: 'C' },
  { id: 7, name: 'Aurelia', category: 'luxury', gradient: 'from-rose-400 to-pink-500', icon: 'A' },
  { id: 8, name: 'Pure', category: 'minimalist', gradient: 'from-zinc-300 to-zinc-500', icon: 'P' },
  { id: 9, name: 'Neon', category: 'retro', gradient: 'from-fuchsia-500 to-purple-600', icon: 'N' },
  { id: 10, name: 'Prism', category: 'abstract', gradient: 'from-emerald-400 to-teal-500', icon: 'P' },
  { id: 11, name: 'Byte', category: 'tech', gradient: 'from-cyan-400 to-blue-500', icon: 'B' },
  { id: 12, name: 'Royal', category: 'luxury', gradient: 'from-violet-600 to-purple-700', icon: 'R' },
];

export function GallerySection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const [mounted, setMounted] = useState(false);
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('all');
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  const filteredItems =
    activeFilter === 'all'
      ? galleryItems
      : galleryItems.filter((item) => item.category === activeFilter);

  return (
    <section id="gallery" ref={ref} className="relative py-24 lg:py-32">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView && mounted ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">
            Logo{' '}
            <span className="gradient-text">Gallery</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Explore stunning logos created by our community
          </p>
        </motion.div>

        {/* Filter Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView && mounted ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {filters.map((filter) => (
            <button
              key={filter.value}
              onClick={() => setActiveFilter(filter.value)}
              className={cn(
                'px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300',
                activeFilter === filter.value
                  ? 'bg-gradient-to-r from-violet-600 to-blue-600 text-white glow-purple'
                  : 'glass hover:bg-white/10 text-muted-foreground hover:text-foreground'
              )}
            >
              {filter.label}
            </button>
          ))}
        </motion.div>

        {/* Gallery Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView && mounted ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6"
        >
          {filteredItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView && mounted ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              className="group relative aspect-square"
              onMouseEnter={() => setHoveredId(item.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              <div className="absolute inset-0 rounded-2xl glass p-4 flex items-center justify-center overflow-hidden">
                {/* Logo Preview */}
                <div
                  className={cn(
                    'w-3/4 h-3/4 rounded-xl bg-gradient-to-br flex items-center justify-center transition-transform duration-300',
                    item.gradient,
                    hoveredId === item.id && 'scale-110'
                  )}
                >
                  <span className="text-4xl lg:text-5xl font-bold text-white/90">
                    {item.icon}
                  </span>
                </div>

                {/* Hover Overlay */}
                <div
                  className={cn(
                    'absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent rounded-2xl flex flex-col justify-end p-4 transition-opacity duration-300',
                    hoveredId === item.id ? 'opacity-100' : 'opacity-0'
                  )}
                >
                  <h3 className="text-white font-semibold mb-1">{item.name}</h3>
                  <span className="text-white/60 text-xs capitalize mb-3">{item.category}</span>
                  <button className="w-full py-2 rounded-lg bg-gradient-to-r from-violet-600 to-blue-600 text-white text-sm font-medium flex items-center justify-center gap-2">
                    <Sparkles className="w-3.5 h-3.5" />
                    Regenerate Similar
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
